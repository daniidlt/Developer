# Entrenamiento
## Este proyecto se usará para decidir el plan de entrenamiento
    * Salto a las vallas
    * Sprints
    * Calentamiento
    * Ejercicios con balón
    * Estiramientos
  
_Se usarán conos, vallas, balones, petos y todo lo necesario para realizar los ejercicios_

__Estado actual: Bueno__ 
    
    Lista de ejercicios

    1. Calentamiento
    2. Salto a las vallas
    3. Sprints
    4. Ejercicios con balón
    5. Estiramientos